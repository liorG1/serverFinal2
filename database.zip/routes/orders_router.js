const { Router } = require("express");
const {allOrders, updateStatus}=require('../controllers/orders_controller.js')
const ordersRouter=Router()
ordersRouter.get('/all',allOrders)
ordersRouter.get('/updateStatus/:id/:status',updateStatus) 

module.exports= ordersRouter