const router=require('express').Router()

const {
    registrate,
    login
}=require('../controllers/users_controller.js')

router.post('/registrate',registrate);
router.post('/login',login)



module.exports=router