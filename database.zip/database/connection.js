
let mongoose=require('mongoose')

let url='mongodb://127.0.0.1:27017/finalProject_1'

let connection=()=> mongoose.connect(url)

module.exports=connection