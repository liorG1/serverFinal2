let mongoose=require('mongoose')

// זה בשביל המנהל כי לכל משתמש נשמור בקולקשיין יוזר את ההזמנות שלו
let order_schema=new mongoose.Schema({
    //כאן אני רוצה את המייל שם מלא טלפון כתובת
    user_detalis:{type:Object,require:true},
    //את ההזמנות נשמור באובייקט כי אפשר להזמין כמה פעמים את אותו המוצר
    products:{type:Object,require:true},
    totalPrice:{type:Number,require:true},
    date:{type:String,require:true},
    status:{type:String,default:'progress'}
    //בהמשך נוסיף אובייקט של תאריך
})

let products_schema=new mongoose.Schema({
    img:{type:String,require:true},
    brand:{type:String,require:true},
    name:{type:String,require:true},
    catagory:{type:Array,require:true},
    price:{type:Number,require:true},
    description:{type:String,require:true}
})

let users_schema=new mongoose.Schema({
    name:{type:String,require:true},
    email:{type:String,require:true},
    phone_number:{type:String,require:true},
    password:{type:String,require:true},
    address:{type:String,require:true},
    permission:{type:Number,require:false},
    products_marked:{type:Array,require:false}
    //הרשאות: 1 זה מנהל אתר 2 זה עורך 3 זה משתמש רגיל
    
})

module.exports={
    Orders:mongoose.model('orders',order_schema),
    Products:mongoose.model('products',products_schema),
    Users:mongoose.model('users',users_schema)
}


