const jwt=require('jsonwebtoken')

const checkPermissionEditor=(req,res,nxt)=>{
    const token=jwt.verify(req.headers['cookie'].split('=')[1],process.env.TOKEN_SECRET)
    if (token.permission!=2){
        res.status(401).send('unathoraized user')
    }
    nxt()
}

const checkPermissionMenager=(req,res,nxt)=>{
    const token=jwt.verify(req.headers['cookie'].split('=')[1],process.env.TOKEN_SECRET)
    if (token.permission!=3){
        res.status(401).send('unathoraized user')
    }
    nxt()
}

module.exports={checkPermissionEditor,checkPermissionMenager}

