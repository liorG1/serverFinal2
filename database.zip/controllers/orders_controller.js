const { Orders } = require("../database/models");

module.exports={
    allOrders:async(req,res)=>{
        try{
                const orders=await Orders.find()
                console.log(orders);
                if (orders){
                    res.status(401,{
                        success:false,
                        message:'no orders'
                    })
                }
                res.status(200).json({
                    orders,
                    success:true,
                    message:'success get all orders'
                })
                
        }catch{
            res.status(401,{
                success:false,
                message:'failed get all orders'
            })
        }
    },
    updateStatus:async(req,res)=>{
        try {
            const order_id=req.params.id
            await Orders.findByIdAndUpdate(order_id,{status:req.params.status})
            res.status(200).json({
                success:true,
                message:'success update status'
            })
        } catch (error) {
            res.status(400).json({
                success:false,
            message:error.message
            })
        }
    }
        
    
}