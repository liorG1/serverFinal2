"use strict";
const nodemailer = require("nodemailer");
const Mailgen=require('mailgen')

function addDays(date, days) {
    const dateCopy = new Date();
    dateCopy.setDate(date.getDate() + days);
    return dateCopy;
  }
const date=new Date()
const SendEmail=async(req,res,order)=>{
    
    const deliveryDay=addDays(date,13)

    let data=[]
    order.products.forEach(product => {
        data.push({
            item:`${product.name}`, 
            img:`<img src="${product.img}" width="100" height="100" />`,
            description:`${product.description}`,
            price:`${product.price}` 
        })
    });

    let config={
        service:'gmail',
        auth:{
            user:'hermainloren@gmail.com',
            pass:'zguopojmlpimltgk'
        }
    }


    let transportere=nodemailer.createTransport(config)

    let mailgenGenerator=new Mailgen({
        "theme":"default",
        "product":{
            name:"lior store",
            link:"https//mailgen.js"
        }
    })

    let response={
        body:{
            name:`${order.user_detalis.name}`,
            intro:`your order number is : ${order._id} \n your expected delivery date : ${deliveryDay.getDate()}/${deliveryDay.getMonth()}/${deliveryDay.getFullYear()}`,
            table:{
                data
            },
            outro:`total price : ${order.totalPrice}`
        }
    }

    let mail=mailgenGenerator.generate(response)

    let messsage={
        from:'liorsStore@gmail.com',
        to:`${order.user_detalis.email}.com`,
        subject:"order completed!!",
        html:mail
    }
    transportere.sendMail(messsage)
}
module.exports=SendEmail
