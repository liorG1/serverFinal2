/* const arr=[{name:"lior",age:24},{name:"mama",age:40},{name:"roni",age:14}]
let x=0
let newArr=[]
arr.map(obj=>{
     if(obj.name=='mama'){
        delete arr[x]
     }
     x++
})
console.log(typeof newArr);
arr.map(obj=>{
    if (obj) newArr.push(obj)
})
console.log( newArr[0].name); */

////////////////////////////////////////////////
/* let lior={name:"lior",age:50,ss:9}

const {name,age}=lior
 */


///////////////////////////////////////////////////

function addDays(date, days) {
    date.setDate(date.getDate() + days);
    return date;
  }
  
  const date = new Date();

  
/*   const newDate = date.setDate(4); */
  
  // 2022-05-20T00:00:00.000Z
  console.log(date.getFullYear());
